/* ========================================
 *
 * Copyright QMAX, 2012
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF QMAX.
 *
 * ========================================
*/

#include "TASK1.h"
#include "TASK2.h"
#include "TASK3.h"

unsigned char prnt_en,i,prt_12,prt_15,prt_12_15,ucKey1Read,ucKey2Read,dat_cnt,cmd_exct;
unsigned char RLY_PRT_STS,val,pos,tst_ch,ref_ch,tst_bank,ref_bank,prt_12_s,e_prb_sts,VI,ShL;
unsigned char spi_tst_ch_tmp,spi_tst_ch_tmp1,spi_ref_ch_tmp,spi_ref_ch_tmp1,SC1,SC2,FG,DMM;
uint16 delay=0x000A;
uint16 swtch_delay=0x0001;

unsigned char tp1[24];
unsigned char k;

void task1 (void) _task_ 1
{
	uint8 p=0,k;
	
	for(;;)
	{
		os_wait1(K_SIG);					//	Wait for Signal from TASK 2
		
		if(prnt_en)
		{
			p=i-1;
			if(i == 0x00)					//	If Local Buffer is empty or overrun Print 0 else Print data
			{
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				UART_WriteTxData(rx_word[1]);
			}
			/*else if()
			{
				for(val = 0; val <= pos; val++)
				{
					UART_WriteTxData(switch_cmd[val]);
				}
			}*/
			else
			{
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				for(k=0 ; k <= p ; k++)
				{
					UART_WriteTxData(rx_word[k]);
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
			}
			prnt_en = 0;
		}
		else
		{
			switching_main(&switch_cmd);
		}
	}
}

void Relays_Init()							// Relays Initialize
{
	if (CyPins_ReadPin(LV_SEL_P15_5))
	{
		CyPins_ClearPin(LV_SEL_P15_5);
	}
	
	if (CyPins_ReadPin(DMM_SEL_P12_2))
	{
		CyPins_ClearPin(DMM_SEL_P12_2);
	}
	
	if (CyPins_ReadPin(DMM_2WSEL_P12_3))
	{
		CyPins_ClearPin(DMM_2WSEL_P12_3);
	}
	
	if (CyPins_ReadPin(I_SEL_P6_1))
	{
		CyPins_ClearPin(I_SEL_P6_1);
	}
	
	if (CyPins_ReadPin(I10mA_SEL_P4_2))
	{
		CyPins_ClearPin(I10mA_SEL_P4_2);
	}
	
	if (CyPins_ReadPin(I100mA_SEL_P4_1))
	{
		CyPins_ClearPin(I100mA_SEL_P4_1);
	}
	
	if (CyPins_ReadPin(I10A_SEL_P4_0))
	{
		CyPins_ClearPin(I10A_SEL_P4_0);
	}
	
	if (CyPins_ReadPin(RES_SEL0_P2_7))
	{	
		CyPins_ClearPin(RES_SEL0_P2_7);
	}
	
	if (CyPins_ReadPin(RES_SEL1_P2_6))
	{
		CyPins_ClearPin(RES_SEL1_P2_6);
	}
	
	if (CyPins_ReadPin(G10M_SEL_P6_0))
	{
		CyPins_ClearPin(G10M_SEL_P6_0);
	}
	
	if (CyPins_ReadPin(RR1_0V_P4_7))
	{
		CyPins_ClearPin(RR1_0V_P4_7);
	}
	
	if (CyPins_ReadPin(RR1_1V_P4_6))
	{
		CyPins_ClearPin(RR1_1V_P4_6);
	}
	
	if (CyPins_ReadPin(RR1_10V_P4_5))
	{
		CyPins_ClearPin(RR1_10V_P4_5);
	}
	
	if (CyPins_ReadPin(RR1_100V_P4_4))
	{
		CyPins_ClearPin(RR1_100V_P4_4);
	}
	
	if (CyPins_ReadPin(RR2_0V_P6_4))
	{
		CyPins_ClearPin(RR2_0V_P6_4);
	}
	
	if (CyPins_ReadPin(RR2_1V_P6_5))
	{
		CyPins_ClearPin(RR2_1V_P6_5);
	}
	
	if (CyPins_ReadPin(RR2_10V_P6_6))
	{
		CyPins_ClearPin(RR2_10V_P6_6);
	}
	
	if (CyPins_ReadPin(RR2_100V_P6_7))
	{
		CyPins_ClearPin(RR2_100V_P6_7);
	}
	
	if (CyPins_ReadPin(S1_100V_P12_5))
	{
		CyPins_ClearPin(S1_100V_P12_5);
	}
	
	if (CyPins_ReadPin(DIV_SEL2_P15_4))
	{
		CyPins_ClearPin(DIV_SEL2_P15_4);
	}
	
	if (CyPins_ReadPin(ICM_SEL_P2_0))
	{
		CyPins_ClearPin(ICM_SEL_P2_0);
	}
	
	if (CyPins_ReadPin(MUXSEL_A_P6_3))
	{
		CyPins_ClearPin(MUXSEL_A_P6_3);
	}
	
	if (CyPins_ReadPin(MUXSEL_B_P6_2))
	{
		CyPins_ClearPin(MUXSEL_B_P6_2);
	}
	
	if (CyPins_ReadPin(VI1_SEL_P2_4))
	{
		CyPins_ClearPin(VI1_SEL_P2_4);
	}
	
	if (CyPins_ReadPin(VI2_SEL_P2_5))
	{
		CyPins_ClearPin(VI2_SEL_P2_5);
	}
	
	if (CyPins_ReadPin(SCOPE1_SEL_P2_3))
	{
		CyPins_ClearPin(SCOPE1_SEL_P2_3);
	}
	
	if (CyPins_ReadPin(SCOPE2_SEL_P2_2))
	{
		CyPins_ClearPin(SCOPE2_SEL_P2_2);
	}
	
	if (CyPins_ReadPin(FG1_SEL_P2_1))
	{
		CyPins_ClearPin(FG1_SEL_P2_1);
	}
}

void k1_k2_check()							//	Subroutine to Check Connection of Probe 1 & 2
{
	ucKey1Read  = CyPins_ReadPin(K1_SENSE_P0_3);
	ucKey2Read  = CyPins_ReadPin(K2_SENSE_P0_7);
}

void VI_ShL_SCP2()							//	Relays common to VI or short Locator & scope_2 Combo
{
	CyPins_ClearPin(LV_SEL_P15_5);
	CyPins_ClearPin(DMM_SEL_P12_2);
	CyPins_ClearPin(DMM_2WSEL_P12_3);
	CyPins_ClearPin(I_SEL_P6_1);
	CyPins_ClearPin(I10mA_SEL_P4_2);
	CyPins_ClearPin(I100mA_SEL_P4_1);
	CyPins_ClearPin(I10A_SEL_P4_0);
	CyPins_ClearPin(RES_SEL0_P2_7);
	CyPins_ClearPin(RES_SEL1_P2_6);
	CyPins_ClearPin(G10M_SEL_P6_0);
	CyPins_ClearPin(RR1_0V_P4_7);
	CyPins_ClearPin(RR1_1V_P4_6);
	CyPins_ClearPin(RR1_10V_P4_5);
	CyPins_ClearPin(RR1_100V_P4_4);
	CyPins_ClearPin(ICM_SEL_P2_0);
	CyPins_ClearPin(MUXSEL_A_P6_3);
	CyPins_ClearPin(MUXSEL_B_P6_2);
	CyPins_ClearPin(FG1_SEL_P2_1);
	
	CyPins_ClearPin(SCOPE1_SEL_P2_3);
	CyPins_ClearPin(RR2_0V_P6_4);
	CyPins_ClearPin(DIV_SEL2_P15_4);
	CyPins_ClearPin(S1_100V_P12_5);
	
	CyPins_ClearPin(FG1_SEL_P2_1);
}

void Scp1_FG_Scp2()							//	Relays common to Scp1_FG_Scp2 combo-Reset Mode
{
	CyPins_ClearPin(LV_SEL_P15_5);
	CyPins_ClearPin(DMM_SEL_P12_2);
	CyPins_ClearPin(DMM_2WSEL_P12_3);
	CyPins_ClearPin(I_SEL_P6_1);
	CyPins_ClearPin(I10mA_SEL_P4_2);
	CyPins_ClearPin(I100mA_SEL_P4_1);
	CyPins_ClearPin(I10A_SEL_P4_0);
	CyPins_ClearPin(RES_SEL1_P2_6);
	CyPins_ClearPin(G10M_SEL_P6_0);
	CyPins_ClearPin(RR1_0V_P4_7);
	CyPins_ClearPin(ICM_SEL_P2_0);
	CyPins_ClearPin(MUXSEL_A_P6_3);
	CyPins_ClearPin(MUXSEL_B_P6_2);
	CyPins_ClearPin(VI1_SEL_P2_4);
	CyPins_ClearPin(VI2_SEL_P2_5);
}

void Test_Chnl_Switch(val_t)
{
	uint16 temp=0x0000;
	uint8 temp1;
	
	if(val_t <= 0x0F)
	{
		temp	= 0x0001 << val_t;
		temp1	= temp >> 0x08;
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}

		CyDelayUs(15);

		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x01);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x02);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x03);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x08);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x11);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
	}
	else if(val_t >= 0x10 && val_t <= 0x1F)
	{
		val_t = val_t - 0x10;
		temp	= 0x0001 << val_t;
		temp1	= temp >> 0x08;		
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x01);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x02);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x03);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x08);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x12);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else if(val_t >= 0x20 && val_t <= 0x2F)
	{
		val_t = val_t - 0x20;
		temp	= 0x0001 << val_t;
		temp1	= temp >> 0x08;
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x01);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x02);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);

		CyPins_ClearPin(CSN_P5_4);

		SPIM_WriteTxData(0x03);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x08);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x14);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else if(val_t >= 0x30 && val_t <= 0x3F)
	{
		val_t = val_t - 0x30;
		temp	= 0x0001 << val_t;
		temp1	= temp >> 0x08;

		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x01);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x02);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x03);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);

		CyPins_ClearPin(CSN_P5_4);

		SPIM_WriteTxData(0x08);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x18);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else
	{
	
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x01);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x02);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);

		CyPins_ClearPin(CSN_P5_4);

		SPIM_WriteTxData(0x03);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);

		CyPins_ClearPin(CSN_P5_4);

		SPIM_WriteTxData(0x08);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	CyDelay(10);
}

void Ref_Chnl_Switch(val_r)
{
	uint16 temp=0x0000;
	uint8 temp1;

	if(val_r <= 0x0F)
	{
		temp	= 0x0001 << val_r;
		temp1	= temp >> 0x08;
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x04);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}

		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x05);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x06);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x07);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x09);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x11);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else if(val_r >= 0x10 && val_r <= 0x1F)
	{
		val_r = val_r - 0x10;
		temp	= 0x0001 << val_r;
		temp1	= temp >> 0x08;
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x04);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x05);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x06);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x07);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x09);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x12);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else if(val_r >= 0x20 && val_r <= 0x2F)
	{
		val_r = val_r - 0x20;
		temp	= 0x0001 << val_r;
		temp1	= temp >> 0x08;
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x04);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x05);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x06);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x07);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x09);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x14);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else if(val_r >= 0x30 && val_r <= 0x3F)
	{
		val_r = val_r - 0x30;
		temp	= 0x0001 << val_r;
		temp1	= temp >> 0x08;

		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x04);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x05);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x06);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x07);
		SPIM_WriteTxData(temp1);
		SPIM_WriteTxData(temp);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x09);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x18);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	else
	{
		CyPins_ClearPin(CSN_P5_4);
	
		SPIM_WriteTxData(0x04);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x05);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x06);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x07);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x09);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
		
		CyDelayUs(20);
		
		CyPins_ClearPin(CSN_P5_4);
		
		SPIM_WriteTxData(0x0F);
		SPIM_WriteTxData(0x00);
		SPIM_WriteTxData(0x00);
		while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
		{
			;
		}
		CyDelayUs(15);
		
		CyPins_SetPin(CSN_P5_4);
	}
	CyDelay(10);
}

void switching_main(unsigned char *cmd)		// Main Relay Switching Subroutine
{
	unsigned char mux_detect,rx_sword[8];
	
	switch(*cmd)

		case 0xF1:										//	VI-CH_1
		{
			//CY_SET_REG8(30,0x01);
			
			Relays_Init();				//	Relays Initialise Subroutine
		
			CyPins_SetPin(VI1_SEL_P2_4);
			
			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
		
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
		
			UART_PutString("#");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			break;
				
		case 0xF2:										//	VI-CH_2
				
			//CY_SET_REG8(30,0x01);
			
			Relays_Init();				//	Relays Initialise Subroutine

			/////  Relay Switched ON /////
				
			CyPins_SetPin(VI2_SEL_P2_5);

			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
				
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
				
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
				
			UART_PutString("#");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}

			//CY_SET_REG8(30,0x00);
			 
			break;

		case 0x03:										//	ICM Select

			//CY_SET_REG8(30,0x01);
			
			Relays_Init();				//	Relays Initialise Subroutine
			
			/////  Relays Switched ON /////
			
			CyPins_SetPin(ICM_SEL_P2_0);
			CyPins_SetPin(VI2_SEL_P2_5);
			
//			ucLastState = CY_SET_REG8(30,0x);
			
			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			//CY_SET_REG8(30,0x00);
			
			break;

		case 0x04:										//	Scope Select
			
			cmd++;
			if(*cmd == 0x00)   		// SCOPE_1 1V //
			{
				//CY_SET_REG8(30,0x01);
					
				Relays_Init();			//	Relays Initialise Subroutine
				
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RR2_0V_P6_4);
				CyPins_SetPin(SCOPE1_SEL_P2_3);
				CyPins_SetPin(RES_SEL0_P2_7);
					
//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
				
			else if(*cmd == 0x01)   // SCOPE_1 10V //
			{	
				//CY_SET_REG8(30,0x01);	
									
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(DIV_SEL2_P15_4);
				CyPins_SetPin(SCOPE1_SEL_P2_3);
				CyPins_SetPin(RES_SEL0_P2_7);
									
//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
									
			else if(*cmd == 0x02)   // SCOPE_1 100V //
			{
				//CY_SET_REG8(30,0x01);	
								
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
								
				CyPins_SetPin(S1_100V_P12_5);
				CyPins_SetPin(SCOPE1_SEL_P2_3);
				CyPins_SetPin(RES_SEL0_P2_7);
									
//				ucLastState = CY_SET_REG8(30,0x);
			
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x03)   // SCOPE_2 1V //
			{
				//CY_SET_REG8(30,0x01);	
						
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
									
				CyPins_SetPin(RR2_1V_P6_5);
				CyPins_SetPin(SCOPE2_SEL_P2_2);

//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x04)   // SCOPE_2 10V //
			{
				//CY_SET_REG8(30,0x01);	
									
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
									
				CyPins_SetPin(RR2_10V_P6_6);
				CyPins_SetPin(SCOPE2_SEL_P2_2);

//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x05)   // SCOPE_2 100V //
			{
				//CY_SET_REG8(30,0x01);
					
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RR2_100V_P6_7);
				CyPins_SetPin(SCOPE2_SEL_P2_2);
					
//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				
				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			
			else						//	Reset local rx_buffer on Unknown Rx Value
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;

				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			
			break;
			
		case 0x05:										//	Short Locator
			
			//CY_SET_REG8(30,0x01);
			
			Relays_Init();			//	Relays Initialise Subroutine
			
			/////  Relays Switched ON /////
			
			CyPins_SetPin(VI2_SEL_P2_5);
			
//			ucLastState = CY_SET_REG8(30,0x);

			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			//CY_SET_REG8(30,0x00);		
			
			break;
			
		case 0x06:										//	Function Generator
		
			//CY_SET_REG8(30,0x01);
			
			Relays_Init();			//	Relays Initialise Subroutine
			
			/////  Relays Switched ON /////
			
			CyPins_SetPin(FG1_SEL_P2_1);
			
//			ucLastState = CY_SET_REG8(30,0x);
			
			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			//CY_SET_REG8(30,0x00);
			
			break;
			
		case 0x07:										//		DMM Select
			
			cmd++;
			
			if(*cmd == 0x00)   				// DMM HV_1000V
			{
				//CY_SET_REG8(30,0x01);
					
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////

				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_100V_P4_4);
				CyPins_SetPin(DMM_SEL_P12_2);
							
//				ucLastState = CY_SET_REG8(30,0x);
			
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			
				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x01)   // DMM HV_200V
			{
				//CY_SET_REG8(30,0x01);
									
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_100V_P4_4);
				CyPins_SetPin(DMM_SEL_P12_2);
																
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
							
			else if(*cmd == 0x02)   // DMM LV_20V //
			{
				//CY_SET_REG8(30,0x01);
									
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
						
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_100V_P4_4);
				CyPins_SetPin(DMM_SEL_P12_2);
														
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
							
			else if(*cmd == 0x03)   // DMM LV_2V //
			{
				//CY_SET_REG8(30,0x01);
		
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_10V_P4_5);
				CyPins_SetPin(DMM_SEL_P12_2);
																
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x04)   // DMM LV_200mV //
			{
				//CY_SET_REG8(30,0x01);
	
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_1V_P4_6);
				CyPins_SetPin(DMM_SEL_P12_2);
																
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x10) ///////  DMM I_3A ///////
			{
				//CY_SET_REG8(30,0x01);
			
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
		
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(I10A_SEL_P4_0);
				CyPins_SetPin(I_SEL_P6_1);
				CyPins_SetPin(RR1_1V_P4_6);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x11) ///////  DMM I_200mA ///////
			{
				//CY_SET_REG8(30,0x01);
			
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////

				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(I100mA_SEL_P4_1);
				CyPins_SetPin(I_SEL_P6_1);
				CyPins_SetPin(RR1_1V_P4_6);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x12)  //////  DMM I_20mA ////
			{
				//CY_SET_REG8(30,0x01);
			
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(I10mA_SEL_P4_2);
				CyPins_SetPin(I_SEL_P6_1);
				CyPins_SetPin(RR1_10V_P4_5);
				CyPins_SetPin(DMM_SEL_P12_2);

//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x13)  ////// DMM I_2mA /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(I10mA_SEL_P4_2);
				CyPins_SetPin(I_SEL_P6_1);
				CyPins_SetPin(RR1_1V_P4_6);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x20)  ////// DMM 2_WIRE_200E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
			
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
									
			else if(*cmd == 0x21)  ////// DMM 2_WIRE_2K E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
			
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x22)  ////// DMM 2_WIRE_20K E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
				
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x23)  ////// DMM 2_WIRE_200K E /////////
			{
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x24)  ////// DMM 2_WIRE_2M E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x25)  ////// DMM 2_WIRE_20M E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(DMM_SEL_P12_2);
				CyPins_SetPin(G10M_SEL_P6_0);
				
//				ucLastState = CY_SET_REG8(30,0x);
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

			}
			
			else if(*cmd == 0x30)  ////// DMM 4_WIRE_200E /////////
		    {
				//CY_SET_REG8(30,0x01);
		
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
			
			else if(*cmd == 0x31)  ////// DMM 4_WIRE_2K E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
									
			else if(*cmd == 0x32)  ////// DMM 4_WIRE_20K E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
									
			else if(*cmd == 0x33)  ////// DMM 4_WIRE_200K E /////////
			{
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
									
			else if(*cmd == 0x34)  ////// DMM 4_WIRE_2M E /////////
			{
				////CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}

			else if(*cmd == 0x35)  ////// DMM 4_WIRE_20M E /////////
		    {
				//CY_SET_REG8(30,0x01);
				
				Relays_Init();			//	Relays Initialise Subroutine	//
			
				/////  Relays Switched ON /////
					
				CyPins_SetPin(RES_SEL0_P2_7);
				CyPins_SetPin(RES_SEL1_P2_6);
				CyPins_SetPin(RR1_0V_P4_7);
				CyPins_SetPin(LV_SEL_P15_5);
				CyPins_SetPin(DMM_2WSEL_P12_3);
				CyPins_SetPin(DMM_SEL_P12_2);
				CyPins_SetPin(G10M_SEL_P6_0);
				
//				ucLastState = CY_SET_REG8(30,0x);	

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}

				//CY_SET_REG8(30,0x00);
			}
				
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;
				
				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			
			break;
			
		case 0x09:										//	Ex-MUX I/F	//
		
			//CY_SET_REG8(30,0x01);
			
//			Relays_Init();			//	Relays Initialise Subroutine	//
//			
//			/////  Relays Switched ON /////
//			
//			CyPins_SetPin(MUXSEL_A_P6_3);
//			CyPins_SetPin(MUXSEL_B_P6_2);
//			
//			CyDelay(swtch_delay);			//	PROGRAMMABLE MODULE SWITCHING DELAY [DEFAULT = 1mS]
			
			cmd++;
			Test_Chnl_Switch(*cmd);
			
			tp1[0] = rx_word[1];
			
			CyDelay(swtch_delay);			//	PROGRAMMABLE MODULE SWITCHING DELAY [DEFAULT = 1mS]
			
			cmd++;
			Ref_Chnl_Switch(*cmd);

			tp1[2] = rx_word[2];
			
			tp1[4] = tst_bank;
			
			tp1[6] = spi_tst_ch_tmp;
			
			tp1[8] = spi_tst_ch_tmp1;
			
			tp1[10] = ref_bank;
			
			tp1[12] = spi_ref_ch_tmp;
			
			tp1[14] = spi_ref_ch_tmp1;

			CyDelay(delay);			//	PROGRAMMABLE DELAY [DEFAULT = 10mS]

			UART_PutString("S");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("U");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("C");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("C");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("E");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("S");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("S");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
//			ucLastState = CY_SET_REG8(30,0x);

			//CY_SET_REG8(30,0x00);
			
			break;
			
		case 0x0A:										//	Ex-MUX Detect	//
			
			//CY_SET_REG8(30,0x01);
			
//			rx_sword[0] = 0x00;
			
			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("#");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			SPIM_ClearTxBuffer();
			
			CyPins_ClearPin(CSN_P5_4);	//	Manual Chip_Select LOW
			
			SPIM_WriteTxData(0x15);
			SPIM_WriteTxData(0x15);
			SPIM_WriteTxData(0x15);
			while(!(SPIM_ReadTxStatus() & SPIM_STS_TX_FIFO_EMPTY))
			{
				rx_sword[0] = SPIM_ReadRxData();
			}

			CyDelayUs(14);

			CyPins_SetPin(CSN_P5_4);	//	Manual Chip_Select HIGH
			
			CyDelayUs(5);
			
			if(SPIM_ReadRxStatus())
			{
				rx_sword[0] = SPIM_ReadRxData();
				
				if(rx_sword[0] == 0x15)
				{
					mux_detect = rx_sword[0];
				}
				else
				{
					mux_detect = 0x00;			// To be changed to 0 after testing is done.
				}
				
				UART_WriteTxData(mux_detect);
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
				SPIM_ClearRxBuffer();
				mux_detect = 0x00;
				rx_sword[0] = 0x00;
			}
			
//			Test_Chnl_Switch(0xFF);
//		
//			CyDelayUs(6);
//	
//			Ref_Chnl_Switch(0xFF);
			
			//CY_SET_REG8(30,0x00);
			break;
			
		case 0x0B:										//	EX-MUX TEST Chnl ON	//
		
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
//			Relays_Init();			//	Relays Initialise Subroutine	//
//			
//			/////  Relays Switched ON /////
//			
//			CyPins_SetPin(MUXSEL_A_P6_3);
//			CyPins_SetPin(MUXSEL_B_P6_2);
			
			Test_Chnl_Switch(*cmd);

			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("#");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			//CY_SET_REG8(30,0x00);
		
			break;
			
		case 0x0C:										//	EX-MUX REF Chnl ON	//
			
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
//			Relays_Init();			//	Relays Initialise Subroutine	//
//			
//			/////  Relays Switched ON /////
//			
//			CyPins_SetPin(MUXSEL_A_P6_3);
//			CyPins_SetPin(MUXSEL_B_P6_2);
			
			Ref_Chnl_Switch(*cmd);

			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("*");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			UART_PutString("#");
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}

			//CY_SET_REG8(30,0x00);
			
			break;
			
		case 0x10:										//	 PWM START	//
			
			PWM_Start();
			PWM_Enable();
			
			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			break;

		case 0x11:										//	 PWM STOP	//
			
			PWM_Stop();
			
			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			
			break;
			
		case 0x12:										//	VI 1_2 and Scope 2	//
			
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
			if(*cmd == 0xF1)							//	VI-CH_1	//
			{
				CyPins_SetPin(VI1_SEL_P2_4);
				
				/////  Relays Switched OFF /////

				CyPins_ClearPin(VI2_SEL_P2_5);
					
				VI_ShL_SCP2();
				
				VI = 0x01;
				
//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
				
			else if(*cmd == 0xF2)						//	VI-CH_2	//
			{
				CyPins_SetPin(VI2_SEL_P2_5);
					
				/////  Relays Switched OFF //////

				CyPins_ClearPin(VI1_SEL_P2_4);					
					
				VI_ShL_SCP2();
				
				VI = 0x01;
				
//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
				
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
				
				VI = 0x01;
				
//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;

				VI = 0x00;

//				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
				
			cmd++;
			if(*cmd == 0x03)   // SCOPE_2 1V //
			{
				CyPins_SetPin(RR2_1V_P6_5);
				CyPins_SetPin(SCOPE2_SEL_P2_2);
					
				/////  Relays Switched OFF //////
				CyPins_ClearPin(RR2_10V_P6_6);
				CyPins_ClearPin(RR2_100V_P6_7);
					
				VI_ShL_SCP2();

				SC2 = 0x01;

//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
				
//				cmd--;
//				if(*cmd == 0x00)
//				{
//					CyPins_ClearPin(VI2_SEL_P2_5);
//				}
//				else if(*cmd == 0x01)
//				{
//					CyPins_ClearPin(VI1_SEL_P2_4);
//				}
			}
				
			else if(*cmd == 0x04)   // SCOPE_2 10V //
			{
				CyPins_SetPin(RR2_10V_P6_6);
				CyPins_SetPin(SCOPE2_SEL_P2_2);
				
				/////  Relays Switched OFF //////
				CyPins_ClearPin(RR2_1V_P6_5);
				CyPins_ClearPin(RR2_100V_P6_7);
					
				VI_ShL_SCP2();

				SC2 = 0x01;

//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
				
//				cmd--;
//				if(*cmd == 0x00)
//				{
//					CyPins_ClearPin(VI2_SEL_P2_5);
//				}
//				else if(*cmd == 0x01)
//				{
//					CyPins_ClearPin(VI1_SEL_P2_4);
//				}
			}
				
			else if(*cmd == 0x05)   // SCOPE_2 100V //
			{
				CyPins_SetPin(RR2_100V_P6_7);
				CyPins_SetPin(SCOPE2_SEL_P2_2);
				
				/////  Relays Switched OFF //////
				CyPins_ClearPin(RR2_1V_P6_5);
				CyPins_ClearPin(RR2_10V_P6_6);
				
				VI_ShL_SCP2();

				SC2 = 0x01;

//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
				
//				cmd--;
//				if(*cmd == 0x00)
//				{
//					CyPins_ClearPin(VI2_SEL_P2_5);
//				}
//				else if(*cmd == 0x01)
//				{
//					CyPins_ClearPin(VI1_SEL_P2_4);
//				}
			}
				
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
				
				SC2 = 0x01;
				
//				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;

				SC2 = 0x00;

//				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//				{
//					;
//				}
			}
			
				if(VI & SC2 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = VI = 0x00;						//	Fault Indication
				}
				else
				{
					if(VI == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("*#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = VI = 0x00;						//	Reset Values
				}
			
			//CY_SET_REG8(30,0x00);
			
			break;
			
			case 0x13:								//	Short Locator & Scope_2	//
				
				//CY_SET_REG8(30,0x01);
				
				cmd++;
				
				if(*cmd == 0x01)		//	Short Locator ON
				{
					//////  Relays Switched ON //////
					CyPins_SetPin(VI2_SEL_P2_5);
					
					/////  Relays Switched OFF //////
					CyPins_ClearPin(VI1_SEL_P2_4);					
					
					VI_ShL_SCP2();
					
					ShL = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

				if(*cmd == 0x00)		//	Short Locator OFF
				{
					//////  Relays Switched ON //////
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					/////  Relays Switched OFF //////
					CyPins_ClearPin(VI1_SEL_P2_4);					
					
					VI_ShL_SCP2();
					
					ShL = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
				else if(0x0F)
				{
					/*	No Change OP	*/
					
					ShL = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
				else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					ShL = 0x00;

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
					
				cmd++;
				if(*cmd == 0x03)   // SCOPE_2 1V //
				{
					CyPins_SetPin(RR2_1V_P6_5);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
					
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_10V_P6_6);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					VI_ShL_SCP2();
					
					SC2 = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
				else if(*cmd == 0x04)   // SCOPE_2 10V //
				{
					CyPins_SetPin(RR2_10V_P6_6);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
				
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					VI_ShL_SCP2();
					
					SC2 = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
										
				else if(*cmd == 0x05)   // SCOPE_2 100V //
				{
					CyPins_SetPin(RR2_100V_P6_7);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
				
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_10V_P6_6);
						
					VI_ShL_SCP2();
					
					SC2 = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
					
				else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					SC2 = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
					
				else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC2 = 0x01;

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

				if(ShL & SC2 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = ShL = 0x00;						//	Fault Indication
				}
				else
				{
					if(ShL == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("*#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = ShL = 0x00;						//	Reset Values
				}

			//CY_SET_REG8(30,0x00);	
				
			break;
			
			case 0x14:									//		DMM & Scope_2 Select		//
			
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
			if(*cmd == 0x00)   // DMM HV_1000V //
				{
			        //  Relays Switched ON //
					
					CyPins_SetPin(RR1_100V_P4_4);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////
					
					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x01)   // DMM HV_200V //
				{
			        //  Relays Switched ON //
				
					CyPins_SetPin(RR1_100V_P4_4);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////
					
					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x02)   // DMM LV_20V //
				{
									
			        //  Relays Switched ON //
						
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_100V_P4_4);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
							
			else if(*cmd == 0x03)   // DMM LV_2V //
				{
		
			        //  Relays Switched ON //
				
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_10V_P4_5);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					DMM = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x04)   // DMM LV_200mV //
				{
	
				    //  Relays Switched ON //
				
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_1V_P4_6);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x10) ///////  DMM I_3A ///////
				{
			
					//////  Relays Switched ON //////
		
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(I10A_SEL_P4_0);
					CyPins_SetPin(I_SEL_P6_1);
					CyPins_SetPin(RR1_1V_P4_6);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x11) ///////  DMM I_200mA ///////
				{
			
					//////  Relays Switched ON //////

					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(I100mA_SEL_P4_1);
					CyPins_SetPin(I_SEL_P6_1);
					CyPins_SetPin(RR1_1V_P4_6);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x12)  //////  DMM I_20mA ////
				{
			
					//////  Relays Switched ON //////
				
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(I10mA_SEL_P4_2);
					CyPins_SetPin(I_SEL_P6_1);
					CyPins_SetPin(RR1_10V_P4_5);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x13)  ////// DMM I_2mA /////////
		        {
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(I10mA_SEL_P4_2);
					CyPins_SetPin(I_SEL_P6_1);
					CyPins_SetPin(RR1_1V_P4_6);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RES_SEL0_P2_7);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

			else if(*cmd == 0x20)  ////// DMM 2_WIRE_200E /////////
		        {
				
					//////  Relays Switched ON //////
						
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
							
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x21)  ////// DMM 2_WIRE_2K E /////////
		        {
				
					//////  Relays Switched ON //////
			
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////

					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x22)  ////// DMM 2_WIRE_20K E /////////
		        {
				
					//////  Relays Switched ON //////
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
				
					/////  Relays Switched OFF //////
				
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x23)  ////// DMM 2_WIRE_200K E /////////
				{
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x24)  ////// DMM 2_WIRE_2M E /////////
		        {
					
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x25)  ////// DMM 2_WIRE_20M E /////////
		        {
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(DMM_SEL_P12_2);
					CyPins_SetPin(G10M_SEL_P6_0);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					DMM = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x30)  ////// DMM 4_WIRE_200E /////////
		        {
					
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
					
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x31)  ////// DMM 4_WIRE_2K E /////////
		        {
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x32)  ////// DMM 4_WIRE_20K E /////////
		        {
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x33)  ////// DMM 4_WIRE_200K E /////////
				{
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x34)  ////// DMM 4_WIRE_2M E /////////
				{
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
								
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(G10M_SEL_P6_0);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					DMM = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}				
				}

			else if(*cmd == 0x35)  ////// DMM 4_WIRE_20M E /////////
		        {
				
					//////  Relays Switched ON //////
					
					CyPins_SetPin(RES_SEL0_P2_7);
					CyPins_SetPin(RES_SEL1_P2_6);
					CyPins_SetPin(RR1_0V_P4_7);
					CyPins_SetPin(LV_SEL_P15_5);
					CyPins_SetPin(DMM_2WSEL_P12_3);
					CyPins_SetPin(DMM_SEL_P12_2);
					CyPins_SetPin(G10M_SEL_P6_0);
					
					/////  Relays Switched OFF //////	

					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);

					DMM = 0x01;

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					DMM = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					DMM = 0x00;

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			cmd++;
			if(*cmd == 0x03)   // SCOPE_2 1V //
				{
					cmd--;
					
					CyPins_SetPin(RR2_1V_P6_5);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
					
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_10V_P6_6);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					SC2 = 0x01;
					
					if(*cmd == 0x00 || *cmd == 0x01 || *cmd == 0x02 || *cmd == 0x03 || *cmd == 0x04)
					{
						if(*cmd == 0x00)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x01)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}						
						else if(*cmd == 0x02)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x03)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						else if(*cmd == 0x04)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_10V_P4_5);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
					else if(*cmd == 0x10 || *cmd == 0x11 || *cmd == 0x12 || *cmd == 0x13)
					{
						if(*cmd == 0x10)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x11)
						{
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x12)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_1V_P4_6);
						}
						else if(*cmd == 0x13)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
					else
					{
						if(*cmd == 0x20 || *cmd == 0x21 || *cmd == 0x22 || *cmd == 0x23 || *cmd == 0x24)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x25)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
						}
						else if(*cmd == 0x30 || *cmd == 0x31 || *cmd == 0x32 || *cmd == 0x33 || *cmd == 0x34)
						{
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x35)
						{
							
						}

						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				}
			else if(*cmd == 0x04)   // SCOPE_2 10V //
				{
					cmd--;
					
					CyPins_SetPin(RR2_10V_P6_6);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
				
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					SC2 = 0x01;
					
					if(*cmd == 0x00 || *cmd == 0x01 || *cmd == 0x02 || *cmd == 0x03 || *cmd == 0x04)
					{
						if(*cmd == 0x00)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x01)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x02)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x03)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						else if(*cmd == 0x04)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_10V_P4_5);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
					else if(*cmd == 0x10 || *cmd == 0x11 || *cmd == 0x12 || *cmd == 0x13)
					{
						if(*cmd == 0x10)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x11)
						{
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x12)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_1V_P4_6);
						}
						else if(*cmd == 0x13)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}					
					else
					{
						if(*cmd == 0x20 || *cmd == 0x21 || *cmd == 0x22 || *cmd == 0x23 || *cmd == 0x24)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x25)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
						}
						else if(*cmd == 0x30 || *cmd == 0x31 || *cmd == 0x32 || *cmd == 0x33 || *cmd == 0x34)
						{
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x35)
						{
							
						}

						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				}
			else if(*cmd == 0x05)   // SCOPE_2 100V //
				{
					cmd--;
					
					CyPins_SetPin(RR2_100V_P6_7);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
				
					/////  Relays Switched OFF //////
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_10V_P6_6);
					
					SC2 = 0x01;
					
					if(*cmd == 0x00 || *cmd == 0x01 || *cmd == 0x02 || *cmd == 0x03 || *cmd == 0x04)
					{
						if(*cmd == 0x00)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x01)
						{
							CyPins_ClearPin(LV_SEL_P15_5);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x02)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x03)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_1V_P4_6);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						else if(*cmd == 0x04)
						{
							CyPins_ClearPin(RES_SEL1_P2_6);
							CyPins_ClearPin(RR1_10V_P4_5);
							CyPins_ClearPin(RR1_100V_P4_4);
						}
						
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
					else if(*cmd == 0x10 || *cmd == 0x11 || *cmd == 0x12 || *cmd == 0x13)
					{
						if(*cmd == 0x10)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x11)
						{
							CyPins_ClearPin(I10mA_SEL_P4_2);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						else if(*cmd == 0x12)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_1V_P4_6);
						}
						else if(*cmd == 0x13)
						{
							CyPins_ClearPin(I100mA_SEL_P4_1);
							CyPins_ClearPin(I10A_SEL_P4_0);
							CyPins_ClearPin(RR1_10V_P4_5);
						}
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(RES_SEL0_P2_7);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_100V_P4_4);							
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
					else
					{
						if(*cmd == 0x20 || *cmd == 0x21 || *cmd == 0x22 || *cmd == 0x23 || *cmd == 0x24)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x25)
						{
							CyPins_ClearPin(DMM_2WSEL_P12_3);
						}
						else if(*cmd == 0x30 || *cmd == 0x31 || *cmd == 0x32 || *cmd == 0x33 || *cmd == 0x34)
						{
							CyPins_ClearPin(G10M_SEL_P6_0);
						}
						else if(*cmd == 0x35)
						{
							
						}

						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						CyPins_ClearPin(SCOPE1_SEL_P2_3);
						CyPins_ClearPin(FG1_SEL_P2_1);

//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				}
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					SC2 = 0x01;
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC2 = 0x00;

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
				if(DMM & SC2 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = DMM = 0x00;						//	Fault Indication
				}
				else
				{
					if(DMM == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("*#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = DMM = 0x00;						//	Reset Values
				}
				
			//CY_SET_REG8(30,0x00);
			
			break;
			
			case 0x15:									//	FG & Scope_1 & Scope_2	//
			
				//CY_SET_REG8(30,0x01);
				
				cmd++;
				
				if(*cmd == 0x01)		// FG ON //
				{
					//////  FG Switched ON //////
					CyPins_SetPin(FG1_SEL_P2_1);
				
					///// Relays Switched OFF //////
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else if(*cmd == 0x00)	// FG OFF //
				{
					//////  FG Switched OFF //////
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else if(*cmd == 0x0F)	// NO CHANGE OP //
				{
					/*	No Change OP	*/
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else						//	Reset local rx_buffer on Unknown Rx Value	//
				{	
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;
					
					FG = 0x00;						//	Fault Indication
					
//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
				cmd++;
				
				if(*cmd == 0x00)   		// SCOPE_1 1V //
					{
						CyPins_SetPin(RR2_0V_P6_4);
						CyPins_SetPin(SCOPE1_SEL_P2_3);
						CyPins_SetPin(RES_SEL0_P2_7);
						
						///// Relays Switched OFF //////
						CyPins_ClearPin(DIV_SEL2_P15_4);
						CyPins_ClearPin(S1_100V_P12_5);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC1 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x01)   // SCOPE_1 10V //
					{	
						CyPins_SetPin(DIV_SEL2_P15_4);
						CyPins_SetPin(SCOPE1_SEL_P2_3);
						CyPins_SetPin(RES_SEL0_P2_7);
						
						///// Relays Switched OFF //////						
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(S1_100V_P12_5);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC1 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x02)   // SCOPE_1 100V //
					{
						CyPins_SetPin(S1_100V_P12_5);
						CyPins_SetPin(SCOPE1_SEL_P2_3);
						CyPins_SetPin(RES_SEL0_P2_7);
						
						///// Relays Switched OFF //////						
						CyPins_ClearPin(RR2_0V_P6_4);
						CyPins_ClearPin(DIV_SEL2_P15_4);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC1 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x0F)
					{
						/*	No Change OP	*/
						
						SC1 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else						//	Reset local rx_buffer on Unknown Rx Value	//
					{	
						for(i = 0; i <= 31; i++)
						{
							rx_word[i]	= 0x00;
						}
						dat_cnt		= 0;
						cmd_exct	= 0;
						
						SC1 = 0x00;						//	Fault Indication
						
//						UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				
				cmd++;
				
				if(*cmd == 0x03)   		// SCOPE_2 1V //
					{
						CyPins_SetPin(RR2_1V_P6_5);
						CyPins_SetPin(SCOPE2_SEL_P2_2);
					
						/////  Relays Switched OFF //////
						CyPins_ClearPin(RR2_10V_P6_6);
						CyPins_ClearPin(RR2_100V_P6_7);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC2 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x04)   // SCOPE_2 10V //
					{
						CyPins_SetPin(RR2_10V_P6_6);
						CyPins_SetPin(SCOPE2_SEL_P2_2);
				
						/////  Relays Switched OFF //////
						CyPins_ClearPin(RR2_1V_P6_5);
						CyPins_ClearPin(RR2_100V_P6_7);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC2 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x05)   // SCOPE_2 100V //
					{
						CyPins_SetPin(RR2_100V_P6_7);
						CyPins_SetPin(SCOPE2_SEL_P2_2);
						
						///// Relays Switched OFF //////						
						CyPins_ClearPin(RR2_1V_P6_5);		
						CyPins_ClearPin(RR2_10V_P6_6);
						
						CyPins_ClearPin(LV_SEL_P15_5);
						CyPins_ClearPin(DMM_SEL_P12_2);
						CyPins_ClearPin(DMM_2WSEL_P12_3);
						CyPins_ClearPin(I_SEL_P6_1);
						CyPins_ClearPin(I10mA_SEL_P4_2);
						CyPins_ClearPin(I100mA_SEL_P4_1);
						CyPins_ClearPin(I10A_SEL_P4_0);
						CyPins_ClearPin(RES_SEL1_P2_6);
						CyPins_ClearPin(G10M_SEL_P6_0);
						CyPins_ClearPin(RR1_0V_P4_7);
						CyPins_ClearPin(RR1_1V_P4_6);
						CyPins_ClearPin(RR1_10V_P4_5);
						CyPins_ClearPin(RR1_100V_P4_4);
						CyPins_ClearPin(ICM_SEL_P2_0);
						CyPins_ClearPin(MUXSEL_A_P6_3);
						CyPins_ClearPin(MUXSEL_B_P6_2);
						CyPins_ClearPin(VI1_SEL_P2_4);
						CyPins_ClearPin(VI2_SEL_P2_5);
						
						SC2 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else if(*cmd == 0x0F)
					{
						/*	No Change OP	*/
						
						SC2 = 0x01;						//	Switching Execute Indication
						
//						UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				else						//	Reset local rx_buffer on Unknown Rx Value	//
					{
						for(i = 0; i <= 31; i++)
						{
							rx_word[i]	= 0x00;
						}
						dat_cnt		= 0;
						cmd_exct	= 0;
						
						SC2 = 0x00;						//	Fault Indication
						
//						UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//						{
//							;
//						}
					}
				if(FG & SC1 & SC2 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					FG = SC1 = SC2 = 0x00;						//	Reset Values
				}
				else
				{
					if(FG == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC1 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					
					FG = SC1 = SC2 = 0x00;						//	Reset Values
				}
			
			break;
			
			case 0x16:						//	Scope_2 & FG & Scope_1	//
			
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
			if(*cmd == 0x03)   		// SCOPE_2 1V //
				{
					/////  Relays Switched ON //////
					CyPins_SetPin(RR2_1V_P6_5);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
					
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_10V_P6_6);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x04)   // SCOPE_2 10V //
				{
									
					/////  Relays Switched ON //////
								
					CyPins_SetPin(RR2_10V_P6_6);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_100V_P6_7);	
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x05)   // SCOPE_2 100V //
				{
					
					/////  Relays Switched ON //////
					CyPins_SetPin(RR2_100V_P6_7);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_1V_P6_5);		
					CyPins_ClearPin(RR2_10V_P6_6);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC2 = 0x00;						//	Fault Indication

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
				cmd++;
				
				if(*cmd == 0x01)
				{
					//////  FG Switched ON //////
					CyPins_SetPin(FG1_SEL_P2_1);
				
					///// Relays Switched OFF //////
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else if(*cmd == 0x00)
				{
					//////  FG Switched OFF //////
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				else						//	Reset local rx_buffer on Unknown Rx Value	//
				{	
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					FG = 0x00;						//	Fault Indication
					
//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			cmd++;
			
			if(*cmd == 0x00)   		// SCOPE_1 1V //
				{
					CyPins_SetPin(RR2_0V_P6_4);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x01)   // SCOPE_1 10V //
				{	
					CyPins_SetPin(DIV_SEL2_P15_4);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x02)   // SCOPE_1 100V //
				{
					CyPins_SetPin(S1_100V_P12_5);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/

					SC1 = 0x01;						//	Switching Execute Indication

//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC1 = 0x00;						//	Fault Indication

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

				if(SC2 & FG & SC1 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = FG = SC1 = 0x00;						//	Fault Indication
				}
				else
				{
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(FG == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC1 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC2 = FG = SC1 = 0x00;						//	Reset Values
				}
				
			break;
			
			case 0x17:										//	Scope_1 & FG & Scope_2	//
			
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
			if(*cmd == 0x00)   		// SCOPE_1 1V //
				{
					
					/////  Relays Switched ON //////
					
					CyPins_SetPin(RR2_0V_P6_4);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////
					CyPins_ClearPin(DIV_SEL2_P15_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x01)   // SCOPE_1 10V //
				{	
									
					/////  Relays Switched ON //////					
									
					CyPins_SetPin(DIV_SEL2_P15_4);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(S1_100V_P12_5);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x02)   // SCOPE_1 100V //
				{
								
					/////  Relays Switched ON //////
								
					CyPins_SetPin(S1_100V_P12_5);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					CyPins_SetPin(RES_SEL0_P2_7);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_0V_P6_4);
					CyPins_ClearPin(DIV_SEL2_P15_4);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					SC1 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC1 = 0x00;						//	Fault Indication

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			cmd++;
			
			if(*cmd == 0x01)		//  FG Switched ON //
				{
					//////  FG Switched ON //////
					CyPins_SetPin(FG1_SEL_P2_1);
				
					///// Relays Switched OFF //////
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			else if(*cmd == 0x00)	//  FG Switched OFF //
				{
					//////  FG Switched OFF //////
					CyPins_ClearPin(FG1_SEL_P2_1);
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			else if(*cmd == 0x0F)	//  NO CHANGE OP //
				{
					/*	No Change OP	*/
					
					FG = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{	
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					FG = 0x00;						//	Fault Indication

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			cmd++;
			
			if(*cmd == 0x03)   		// SCOPE_2 1V //
				{
					/////  Relays Switched ON //////
					CyPins_SetPin(RR2_1V_P6_5);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
					
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_10V_P6_6);
					CyPins_ClearPin(RR2_100V_P6_7);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x04)   // SCOPE_2 10V //
				{
					/////  Relays Switched ON //////
					CyPins_SetPin(RR2_10V_P6_6);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_1V_P6_5);
					CyPins_ClearPin(RR2_100V_P6_7);	
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
									
			else if(*cmd == 0x05)   // SCOPE_2 100V //
				{
					/////  Relays Switched ON //////
					CyPins_SetPin(RR2_100V_P6_7);
					CyPins_SetPin(SCOPE2_SEL_P2_2);
						
					///// Relays Switched OFF //////						
					CyPins_ClearPin(RR2_1V_P6_5);		
					CyPins_ClearPin(RR2_10V_P6_6);
					
					CyPins_ClearPin(LV_SEL_P15_5);
					CyPins_ClearPin(DMM_SEL_P12_2);
					CyPins_ClearPin(DMM_2WSEL_P12_3);
					CyPins_ClearPin(I_SEL_P6_1);
					CyPins_ClearPin(I10mA_SEL_P4_2);
					CyPins_ClearPin(I100mA_SEL_P4_1);
					CyPins_ClearPin(I10A_SEL_P4_0);
					CyPins_ClearPin(RES_SEL1_P2_6);
					CyPins_ClearPin(G10M_SEL_P6_0);
					CyPins_ClearPin(RR1_0V_P4_7);
					CyPins_ClearPin(RR1_1V_P4_6);
					CyPins_ClearPin(RR1_10V_P4_5);
					CyPins_ClearPin(RR1_100V_P4_4);
					CyPins_ClearPin(ICM_SEL_P2_0);
					CyPins_ClearPin(MUXSEL_A_P6_3);
					CyPins_ClearPin(MUXSEL_B_P6_2);
					CyPins_ClearPin(VI1_SEL_P2_4);
					CyPins_ClearPin(VI2_SEL_P2_5);
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					SC2 = 0x01;						//	Switching Execute Indication
					
//					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					SC2 = 0x00;						//	Fault Indication

//					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
//					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//					{
//						;
//					}
				}

				if(SC1 & FG & SC2 == 0x01)
				{
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC1 = FG = SC2 = 0x00;						//	Reset Values
				}
				else
				{
					if(SC1 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(FG == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					if(SC2 == 0x00)
					{
						UART_PutString("?");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					else
					{
						UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
						while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
						{
							;
						}
					}
					
					UART_PutString("#");				//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					SC1 = FG = SC2 = 0x00;						//	Reset Values
				}
			
			break;
			
		case 0x18:										//	Embedded Probe Status	//
		
			//CY_SET_REG8(30,0x01);
			
//			UART_PutString("*");			//	STATUS ACKNOWLEDGEMENT to uP	//
//			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//			{
//				;
//			}
//			
//			UART_PutString("*");
//			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//			{
//				;
//			}
//			
//			UART_PutString("*");
//			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//			{
//				;
//			}
//			
//			UART_PutString("#");
//			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//			{
//				;
//			}
//			
//			e_prb_sts = CY_GET_REG8(CYDEV_IO_PRT_PRT0_PS);
//			e_prb_sts = ~e_prb_sts;
//			e_prb_sts = e_prb_sts & 0x88;
//			e_prb_sts = e_prb_sts >> 3;
//			UART_ClearTxBuffer();
//			UART_WriteTxData(e_prb_sts);
//			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
//			{
//				;
//			}
			
			//CY_SET_REG8(30,0x00);
		
			break;
			
		case 0x1C:										//	Interrupt Pin Configure	//
		
			//CY_SET_REG8(30,0x01);
			
			cmd++;
			
			if(*cmd == 0x00 || *cmd == 0x01)
			{
				embd_prb_int_config = *cmd;
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/

				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else						//	Reset local rx_buffer on Unknown Rx Value	//
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;

				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}

			//CY_SET_REG8(30,0x00);
			
			break;
			
		case 0x40:										//	Debug Mode	//
		
			//CY_SET_REG8(30,0x01);

			Relays_Init();			//	Relays Initialise Subroutine	//

//			ucLastState = CY_SET_REG8(30,0x);

			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}

			//CY_SET_REG8(30,0x00);
			break;
			
		case 0x41:										//	Relay Top On	//
			cmd++;
			if(*cmd == 0x01)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(SCOPE1_SEL_P2_3);
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					
					//CY_SET_REG8(30,0x00);					
				}
							
			else if(*cmd == 0x03)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);				
				}
								
			else if(*cmd == 0x04)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);				
				}
								
			else if(*cmd == 0x05)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x06)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x07)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(FG1_SEL_P2_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x09)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x10)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x11)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(LV_SEL_P15_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x12)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(I_SEL_P6_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
			else if(*cmd == 0x13)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x14)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RES_SEL0_P2_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x15)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR1_0V_P4_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x16)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DMM_2WSEL_P12_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x17)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR1_1V_P4_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x18)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
									
			else if(*cmd == 0x19)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR1_10V_P4_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x20)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR1_100V_P4_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x21)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(I10mA_SEL_P4_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x22)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(I100mA_SEL_P4_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x23)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(I10A_SEL_P4_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x24)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RES_SEL1_P2_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x25)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(G10M_SEL_P6_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x26)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(I_SEL_P6_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x27)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RES_SEL0_P2_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x36)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DIV_SEL2_P15_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x37)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_0V_P6_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x38)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(S1_100V_P12_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x39)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(DIV_SEL2_P15_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x40)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(S1_100V_P12_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}				
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
			break;
			
		case 0x42:										//	Relay Bottom On	//
			cmd++;

			if(*cmd == 0x01)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_1V_P6_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x02)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_10V_P6_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x03)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(SCOPE2_SEL_P2_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x04)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_100V_P6_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x05)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_10V_P6_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x06)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(RR2_100V_P6_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
			
			else if(*cmd == 0x08)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
							
			else if(*cmd == 0x09)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(MUXSEL_A_P6_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x10)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x11)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x12)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(MUXSEL_A_P6_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x13)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(ICM_SEL_P2_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x14)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
													
			else if(*cmd == 0x15)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(MUXSEL_B_P6_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x16)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_SetPin(MUXSEL_B_P6_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);		
				}

			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
			break;

		case 0x43:										//	Relay Top Off	//
			cmd++;
			if(*cmd == 0x01)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(SCOPE1_SEL_P2_3);
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
					
					//CY_SET_REG8(30,0x00);					
				}
							
			else if(*cmd == 0x03)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);				
				}
								
			else if(*cmd == 0x04)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);				
				}
								
			else if(*cmd == 0x05)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x06)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI1_SEL_P2_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x07)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(FG1_SEL_P2_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x09)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x10)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x11)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(LV_SEL_P15_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x12)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(I_SEL_P6_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
			else if(*cmd == 0x13)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x14)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RES_SEL0_P2_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x15)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR1_0V_P4_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x16)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DMM_2WSEL_P12_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x17)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR1_1V_P4_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x18)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DMM_SEL_P12_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
									
			else if(*cmd == 0x19)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR1_10V_P4_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x20)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR1_100V_P4_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x21)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(I10mA_SEL_P4_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x22)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(I100mA_SEL_P4_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x23)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(I10A_SEL_P4_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x24)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RES_SEL1_P2_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x25)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(G10M_SEL_P6_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x26)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(I_SEL_P6_1);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x27)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RES_SEL0_P2_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x36)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DIV_SEL2_P15_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x37)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_0V_P6_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x38)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(S1_100V_P12_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
				
			else if(*cmd == 0x39)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(DIV_SEL2_P15_4);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x40)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(S1_100V_P12_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}				
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
			break;

		case 0x44:										//	Relay Bottom Off	//
		
			cmd++;
			if(*cmd == 0x01)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_1V_P6_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x02)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_10V_P6_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x03)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(SCOPE2_SEL_P2_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x04)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_100V_P6_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x05)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_10V_P6_6);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}

			else if(*cmd == 0x06)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(RR2_100V_P6_7);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
			
			else if(*cmd == 0x08)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
							
			else if(*cmd == 0x09)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(MUXSEL_A_P6_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x10)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x11)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x12)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(MUXSEL_A_P6_3);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x13)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(ICM_SEL_P2_0);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x14)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(VI2_SEL_P2_5);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
													
			else if(*cmd == 0x15)
				{
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(MUXSEL_B_P6_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);
				}
								
			else if(*cmd == 0x16)
				{			
					//CY_SET_REG8(30,0x01);
					CyPins_ClearPin(MUXSEL_B_P6_2);

					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}

					//CY_SET_REG8(30,0x00);		
				}

			else if(*cmd == 0x0F)
				{
					/*	No Change OP	*/
					
					UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
				
			else						//	Reset local rx_buffer on Unknown Rx Value	//
				{
					for(i = 0; i <= 31; i++)
					{
						rx_word[i]	= 0x00;
					}
					dat_cnt		= 0;
					cmd_exct	= 0;

					UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
					while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
					{
						;
					}
				}
			break;
			
		case 0x45:										//	Read Port Status	//
		
			//CY_SET_REG8(30,0x01);

			UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}

			RLY_PRT_STS	= CY_GET_REG8(CYDEV_IO_PRT_PRT2_PS);
			UART_ClearTxBuffer();
			UART_WriteTxData(RLY_PRT_STS);
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
					
			RLY_PRT_STS	= CY_GET_REG8(CYDEV_IO_PRT_PRT4_PS);
			RLY_PRT_STS	= RLY_PRT_STS & 0xf7;
			UART_WriteTxData(RLY_PRT_STS);
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
					
			RLY_PRT_STS	= CY_GET_REG8(CYDEV_IO_PRT_PRT6_PS);
			UART_WriteTxData(RLY_PRT_STS);
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}
			prt_12		= CY_GET_REG8(CYDEV_IO_PRT_PRT12_PS);
			prt_12		= prt_12 & 0x2c;
			prt_12		= prt_12 << 2;
			
			prt_15	= CY_GET_REG8(CYDEV_IO_PRT_PRT15_PS);
			prt_15	= prt_15 & 0x30;
			prt_15	= prt_15 >> 2;
			
//			prt_12		= CY_GET_REG8(CYDEV_IO_PRT_PRT12_PS);
//			prt_12		= prt_12 & 0x2c;
//			prt_12_s	= prt_12 & 0x20;
//			prt_12		= prt_12 << 1;
//			prt_12		= prt_12 & 18;
//			prt_12		= prt_12 + prt_12_s;

//			prt_15	= CY_GET_REG8(CYDEV_IO_PRT_PRT15_PS);
//			prt_15	= prt_15 & 0x30;
//			prt_15	= prt_15 << 2;
					
			prt_12_15	= prt_15 | prt_12;
			
			UART_WriteTxData(prt_12_15);
			while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
			{
				;
			}

//			ucLastState = CY_SET_REG8(30,0x);

			//CY_SET_REG8(30,0x00);
			break;
			
		case 0x50:										//	BAUD RATE CHANGE	//
		
			cmd++;
			//CY_SET_REG8(30,0x01);
			
			if(*cmd == 0x01)			// Select 9600 BAUD Rate	//
			{
				UART_Stop();
				U_CLOCK_SetDividerValue(156);
				UART_Start();
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x02)		// Select 19200 BAUD Rate	//
			{
				UART_Stop();
				U_CLOCK_SetDividerValue(78);
				UART_Start();
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x03)		// Select 38400 BAUD Rate	//
			{
				UART_Stop();
				U_CLOCK_SetDividerValue(38);
				UART_Start();
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x04)		// Select 57600 BAUD Rate	//
			{
				UART_Stop();
				U_CLOCK_SetDividerValue(26);
				UART_Start();
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x05)		// Select 115200 BAUD Rate	//
			{
				UART_Stop();
				U_CLOCK_SetDividerValue(13);
				UART_Start();
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
			
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;
				
				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			
			//CY_SET_REG8(30,0x00);
			break;
		
		case 0xFF:									//	SOFTWARE RESET
		
			cmd++;
			if(*cmd == 0xFF)						
			{
				CySoftwareReset();					//	SOFTWARE RESET COMMAND
			}
			else if(*cmd == 0x0F)
			{
				/*	No Change OP	*/
				
				UART_PutString("***#");			//	STATUS ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			else
			{
				for(i = 0; i <= 31; i++)
				{
					rx_word[i]	= 0x00;
				}
				dat_cnt		= 0;
				cmd_exct	= 0;
				
				UART_PutString("***?");			//	FAILURE ACKNOWLEDGEMENT to uP	//
				while(!(UART_ReadTxStatus() & UART_TX_STS_FIFO_EMPTY))
				{
					;
				}
			}
			break;
		}
}

void TASK_1 ()								//	INITIALISATION FUNCTION OF TASK1
{
	os_create_task(1);						//	CREATION OF TASK1
}

/* [] END OF FILE */
