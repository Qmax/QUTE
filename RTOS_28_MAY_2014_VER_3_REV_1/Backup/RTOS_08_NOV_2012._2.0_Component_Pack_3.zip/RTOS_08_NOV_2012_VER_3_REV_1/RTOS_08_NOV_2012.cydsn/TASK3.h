/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#if !defined(__TASK3_H__)
#define __TASK3_H__
#include <rtx51tny.h>

#include <device.h>
extern uint8 count;
extern unsigned char k_port,k_val;

void TASK_3 (void);

//[] END OF FILE
