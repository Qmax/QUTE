/*******************************************************************************
* File Name: DIV_SEL2.h  
* Version 1.60
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_DIV_SEL2_ALIASES_H) /* Pins DIV_SEL2_ALIASES_H */
#define CY_PINS_DIV_SEL2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"

/***************************************
*              Constants        
***************************************/
#define DIV_SEL2_0		DIV_SEL2__0__PC

#define DIV_SEL2_P15_4		DIV_SEL2__P15_4__PC

#endif /* End Pins DIV_SEL2_ALIASES_H */

/* [] END OF FILE */
