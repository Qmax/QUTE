/*******************************************************************************
* File Name: RL6_CTR.h  
* Version 1.60
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_RL6_CTR_ALIASES_H) /* Pins RL6_CTR_ALIASES_H */
#define CY_PINS_RL6_CTR_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"

/***************************************
*              Constants        
***************************************/
#define RL6_CTR_0		RL6_CTR__0__PC

#define RL6_CTR_P12_3		RL6_CTR__P12_3__PC

#endif /* End Pins RL6_CTR_ALIASES_H */

/* [] END OF FILE */
