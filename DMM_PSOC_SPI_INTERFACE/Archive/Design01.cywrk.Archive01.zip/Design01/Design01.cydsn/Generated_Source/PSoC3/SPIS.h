/*******************************************************************************
* File Name: SPIS.h
* Version 2.20
*
* Description:
*  Contains the function prototypes, constants and register definition
*  of the SPI Slave Component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2011, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SPIS_SPIS_H)
#define CY_SPIS_SPIS_H

#include "cyfitter.h"

/* Check to see if required defines such as CY_PSOC3 and CY_PSOC5 are available */
/* They are defined starting with cy_boot v2.30 */
#ifndef CY_PSOC3
	#error Component SPI_Slave_v2_20 requires cy_boot v2.30 or later
#endif

#ifdef SPIS_TxInternalInterrupt__ES2_PATCH
    #if(CY_PSOC3_ES2 && SPIS_TxInternalInterrupt__ES2_PATCH)
        #include <intrins.h>
        #define SPIS_TX_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif /* End PSOC3_ES2 */
#endif /* SPIS_TxInternalInterrupt__ES2_PATCH */

#ifdef SPIS_RxInternalInterrupt__ES2_PATCH
    #if(CY_PSOC3_ES2 && SPIS_RxInternalInterrupt__ES2_PATCH)
        #include <intrins.h>
        #define SPIS_RX_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif /* End PSOC3_ES2 */
#endif /* SPIS_RxInternalInterrupt__ES2_PATCH */


/***************************************
*   Conditional Compilation Parameters
***************************************/

#define SPIS_DataWidth                  (9u)
#define SPIS_InternalTxInterruptEnabled (1u)
#define SPIS_InternalRxInterruptEnabled (1u)
#define SPIS_ModeUseZero                (1u)
#define SPIS_BidirectionalMode          (0u)
#define SPIS_Mode                       (0u)

/* Following definitions are for version Compatibility, they are obsolete.
*  Please do not use it in new projects
*/
#define SPIS_DATAWIDHT                (SPIS_DataWidth)
#define SPIS_InternalInterruptEnabled (0u)


/***************************************
*        Data Struct Definition
***************************************/

/* Sleep Mode API Support */
typedef struct _SPIS_backupStruct
{
    uint8 enableState;
    uint8 cntrPeriod;

    #if(CY_PSOC3_ES2 || CY_PSOC5_ES1) /* PSoC3 ES2 or earlier, PSoC5 ES1 */

        uint16 saveSrTxIntMask;
        uint16 saveSrRxIntMask;

    #endif /* End CY_PSOC3_ES2 || CY_PSOC5_ES1 */

} SPIS_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

void  SPIS_Init(void);
void  SPIS_Enable(void) ;
void  SPIS_Start(void);
void  SPIS_Stop(void) ;
void  SPIS_EnableTxInt(void) ;
void  SPIS_EnableRxInt(void) ;
void  SPIS_DisableTxInt(void) ;
void  SPIS_DisableRxInt(void) ;
void  SPIS_SetTxInterruptMode(uint8 intSource) ;
void  SPIS_SetRxInterruptMode(uint8 intSource) ;
uint8 SPIS_ReadTxStatus(void);
uint8 SPIS_ReadRxStatus(void);
void  SPIS_WriteTxData(uint16 txData);

#if(SPIS_ModeUseZero == 1u)
    void  SPIS_WriteTxDataZero(uint16 txDataByte) \
                                              ;
#endif /* (SPIS_ModeUseZero == 1u) */

uint16 SPIS_ReadRxData(void);
uint8 SPIS_GetRxBufferSize(void) ;
uint8 SPIS_GetTxBufferSize(void) ;
void  SPIS_ClearRxBuffer(void);
void  SPIS_ClearTxBuffer(void);

#if (SPIS_BidirectionalMode == 1u)
    void  SPIS_TxEnable(void) ;
    void  SPIS_TxDisable(void) ;
#endif /* SPIS_BidirectionalMode == 1u */

void  SPIS_PutArray(uint16 *buffer, uint8 byteCount);
void  SPIS_ClearFIFO(void) ;
void  SPIS_Sleep(void);
void  SPIS_Wakeup(void);
void  SPIS_SaveConfig(void);
void  SPIS_RestoreConfig(void) ;

CY_ISR_PROTO(SPIS_TX_ISR);
CY_ISR_PROTO(SPIS_RX_ISR);

/* Macros for getting software status of SPIS Statusi Register */
#define SPIS_GET_STATUS_TX(swTxSts) (uint8)(SPIS_TX_STATUS_REG | \
                                                       (swTxSts & SPIS_STS_CLR_ON_RD_BYTES_MASK))
#define SPIS_GET_STATUS_RX(swRxSts) (uint8)(SPIS_RX_STATUS_REG | \
                                                       (swRxSts & SPIS_STS_CLR_ON_RD_BYTES_MASK))

/* Following definitions are for version Compatibility, they are obsolete.
*  Please do not use it in new projects
*/
#define SPIS_WriteByte      (SPIS_WriteTxData)
#define SPIS_ReadByte       (SPIS_ReadRxData)
#define SPIS_WriteByteZero  (SPIS_WriteTxDataZero)
void  SPIS_SetInterruptMode(uint8 intSource) ;
uint8 SPIS_ReadStatus(void);
void  SPIS_EnableInt(void) ;
void  SPIS_DisableInt(void) ;


/***************************************
*           API Constants
***************************************/

#define SPIS_TX_ISR_NUMBER     (SPIS_TxInternalInterrupt__INTC_NUMBER)
#define SPIS_RX_ISR_NUMBER     (SPIS_RxInternalInterrupt__INTC_NUMBER)
#define SPIS_TX_ISR_PRIORITY   (SPIS_TxInternalInterrupt__INTC_PRIOR_NUM)
#define SPIS_RX_ISR_PRIORITY   (SPIS_RxInternalInterrupt__INTC_PRIOR_NUM)


/***************************************
*    Initial Parameter Constants
***************************************/

#define SPIS_INT_ON_SPI_DONE    (1u << SPIS_STS_SPI_DONE_SHIFT)
#define SPIS_INT_ON_TX_EMPTY    (1u << SPIS_STS_TX_FIFO_EMPTY_SHIFT)
#define SPIS_INT_ON_TX_NOT_FULL (0u << SPIS_STS_TX_FIFO_NOT_FULL_SHIFT)
#define SPIS_INT_ON_BYTE_COMP   (0u << SPIS_STS_BYTE_COMPLETE_SHIFT)

#define SPIS_TX_INIT_INTERRUPTS_MASK  (SPIS_INT_ON_SPI_DONE | \
                                            SPIS_INT_ON_TX_EMPTY | SPIS_INT_ON_TX_NOT_FULL | \
                                            SPIS_INT_ON_BYTE_COMP)

#define SPIS_INT_ON_RX_EMPTY     (1u << SPIS_STS_RX_FIFO_EMPTY_SHIFT)
#define SPIS_INT_ON_RX_NOT_EMPTY (1u << SPIS_STS_RX_FIFO_NOT_EMPTY_SHIFT)
#define SPIS_INT_ON_RX_OVER      (0u << SPIS_STS_RX_FIFO_OVERRUN_SHIFT)
#define SPIS_INT_ON_RX_FULL      (0u << SPIS_STS_RX_FIFO_FULL_SHIFT)

#define SPIS_RX_INIT_INTERRUPTS_MASK (SPIS_INT_ON_RX_EMPTY | \
                                            SPIS_INT_ON_RX_NOT_EMPTY | SPIS_INT_ON_RX_OVER | \
                                            SPIS_INT_ON_RX_FULL)

#define SPIS_BITCTR_INIT           (SPIS_DataWidth - 1u)

#define SPIS__MODE_00 0
#define SPIS__MODE_01 1
#define SPIS__MODE_10 2
#define SPIS__MODE_11 3


#define SPIS_TXBUFFERSIZE          (4u)
#define SPIS_RXBUFFERSIZE          (4u)

/* Following definitions are for version Compatibility, they are obsolete.
*  Please do not use it in new projects
*/
#define SPIS_INIT_INTERRUPTS_MASK  (SPIS_INT_ON_SPI_DONE | SPIS_INT_ON_TX_EMPTY | \
                                            SPIS_INT_ON_TX_NOT_FULL | SPIS_INT_ON_RX_EMPTY | \
                                            SPIS_INT_ON_RX_NOT_EMPTY | SPIS_INT_ON_RX_OVER | \
                                            SPIS_INT_ON_BYTE_COMP)


/***************************************
*             Registers
***************************************/

#if(CY_PSOC3_ES2 || CY_PSOC5_ES1)

    #define SPIS_TXDATA_ZERO_REG           (* (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__A0_REG)

    #define SPIS_TXDATA_ZERO_PTR           (  (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__A0_REG)

    #define SPIS_RXDATA_ZERO_REG           (* (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMOSI_u0__A0_REG)

    #define SPIS_RXDATA_ZERO_PTR           (  (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMOSI_u0__A0_REG)

    #define SPIS_TXDATA_REG                (* (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__F0_REG)

    #define SPIS_TXDATA_PTR                (  (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__F0_REG)

    #define SPIS_RXDATA_REG                (* (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMOSI_u0__F0_REG)

    #define SPIS_RXDATA_PTR                (  (reg16  *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMOSI_u0__F0_REG)

    #define SPIS_TX_AUX_CONTROL_DP0_REG       (* (reg8 *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__DP_AUX_CTL_REG)
    #define SPIS_TX_AUX_CONTROL_DP0_PTR       (  (reg8 *) \
            SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u0__DP_AUX_CTL_REG)

    #if(SPIS_DataWidth > 8u)

        #define SPIS_TX_AUX_CONTROL_DP1_REG   (* (reg8 *) \
                SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u1__DP_AUX_CTL_REG)
        #define SPIS_TX_AUX_CONTROL_DP1_PTR   (  (reg8 *) \
                SPIS_BSPIS_es2_SPISlave_sR16_DpMISO_u1__DP_AUX_CTL_REG)

    #endif /* SPIS_DataWidth > 8u */

#else /* CY_PSOC3_ES3  || CY_PSOC5_ES2 or later */

    #define SPIS_TXDATA_ZERO_REG          (* (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__A0_REG)

    #define SPIS_TXDATA_ZERO_PTR           (  (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__A0_REG)

    #define SPIS_RXDATA_ZERO_REG           (* (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__A0_REG)

    #define SPIS_RXDATA_ZERO_PTR           (  (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__A0_REG)

    #define SPIS_TXDATA_REG                (* (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__F0_REG)

    #define SPIS_TXDATA_PTR                (  (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__F0_REG)

    #define SPIS_RXDATA_REG                (* (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__F1_REG)

    #define SPIS_RXDATA_PTR                (  (reg16  *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__F1_REG)

    #define SPIS_TX_AUX_CONTROL_DP0_REG       (* (reg8 *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__DP_AUX_CTL_REG)
    #define SPIS_TX_AUX_CONTROL_DP0_PTR       (  (reg8 *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__DP_AUX_CTL_REG)

    #define SPIS_RX_AUX_CONTROL_DP0_REG       (* (reg8 *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__DP_AUX_CTL_REG)
    #define SPIS_RX_AUX_CONTROL_DP0_PTR       (  (reg8 *) \
            SPIS_BSPIS_es3_SPISlave_sR16_Dp_u0__DP_AUX_CTL_REG)

    #if(SPIS_DataWidth > 8u)

        #define SPIS_TX_AUX_CONTROL_DP1_REG   (* (reg8 *) \
                SPIS_BSPIS_es3_SPISlave_sR16_Dp_u1__DP_AUX_CTL_REG)
        #define SPIS_TX_AUX_CONTROL_DP1_PTR   (  (reg8 *) \
                SPIS_BSPIS_es3_SPISlave_sR16_Dp_u1__DP_AUX_CTL_REG)

        #define SPIS_RX_AUX_CONTROL_DP1_REG   (* (reg8 *) \
                SPIS_BSPIS_es3_SPISlave_sR16_Dp_u1__DP_AUX_CTL_REG)
        #define SPIS_RX_AUX_CONTROL_DP1_PTR   (  (reg8 *) \
                SPIS_BSPIS_es3_SPISlave_sR16_Dp_u1__DP_AUX_CTL_REG)

    #endif /* SPIS_DataWidth > 8u */

#endif /* (CY_PSOC3_ES2 || CY_PSOC5_ES1) or earlier */

#define SPIS_COUNTER_PERIOD_REG    (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_BitCounter__PERIOD_REG)
#define SPIS_COUNTER_PERIOD_PTR    (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_BitCounter__PERIOD_REG)

#define SPIS_TX_STATUS_MASK_REG    (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_TxStsReg__MASK_REG)
#define SPIS_TX_STATUS_MASK_PTR    (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_TxStsReg__MASK_REG)

#define SPIS_RX_STATUS_MASK_REG    (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_RxStsReg__MASK_REG)
#define SPIS_RX_STATUS_MASK_PTR    (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_RxStsReg__MASK_REG)

#define SPIS_ONE_REG               (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_dpCounter_u0__D1_REG)
#define SPIS_ONE_PTR               (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_dpCounter_u0__D1_REG)

#define SPIS_TX_STATUS_REG         (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_TxStsReg__STATUS_REG)
#define SPIS_TX_STATUS_PTR         (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_TxStsReg__STATUS_REG)

#define SPIS_RX_STATUS_REG         (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_RxStsReg__STATUS_REG)
#define SPIS_RX_STATUS_PTR         (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_RxStsReg__STATUS_REG)

#define SPIS_COUNTER_CONTROL_REG   (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_BitCounter__CONTROL_AUX_CTL_REG)
#define SPIS_COUNTER_CONTROL_PTR   (  (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_BitCounter__CONTROL_AUX_CTL_REG)

#define SPIS_TX_STATUS_ACTL_REG    (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_TxStsReg__STATUS_AUX_CTL_REG)
#define SPIS_TX_STATUS_ACTL_PTR    (  (reg8 *) \
        SPIS_TX_BSPIS_es3_SPISlave_TxStsReg__STATUS_AUX_CTL_REG)

#define SPIS_RX_STATUS_ACTL_REG    (* (reg8 *) \
        SPIS_BSPIS_es3_SPISlave_RxStsReg__STATUS_AUX_CTL_REG)
#define SPIS_RX_STATUS_ACTL_PTR    (  (reg8 *) \
        SPIS_RX_BSPIS_es3_SPISlave_RxStsReg__STATUS_AUX_CTL_REG)

#if(SPIS_BidirectionalMode)

    #define SPIS_CONTROL_REG       (* (reg8 *) \
   SPIS_BSPIS_es3_SPISlave_SyncCtl_CtrlReg__CONTROL_REG)
    #define SPIS_CONTROL_PTR       (  (reg8 *) \
   SPIS_BSPIS_es3_SPISlave_SyncCtl_CtrlReg__CONTROL_REG)

#endif /* SPIS_BidirectionalMode */

/* Obsolete register names. Not to be used in new designs */
#define SPIS_TXDATA_ZERO               (SPIS_TXDATA_ZERO_REG)
#define SPIS_TXDATA                    (SPIS_TXDATA_REG)
#define SPIS_RXDATA                    (SPIS_RXDATA_REG)
#define SPIS_MISO_AUX_CONTROLDP0       (SPIS_MISO_AUX_CTRL_DP0_REG)
#define SPIS_MOSI_AUX_CONTROLDP0       (SPIS_MOSI_AUX_CTRL_DP0_REG)
#define SPIS_TXBUFFERREAD              (SPIS_txBufferRead)
#define SPIS_TXBUFFERWRITE             (SPIS_txBufferWrite)
#define SPIS_RXBUFFERREAD              (SPIS_rxBufferRead)
#define SPIS_RXBUFFERWRITE             (SPIS_rxBufferWrite)

#if(SPIS_DataWidth > 8u)

    #define SPIS_MISO_AUX_CONTROLDP1   (SPIS_MISO_AUX_CTRL_DP1_REG)
    #define SPIS_MOSI_AUX_CONTROLDP1   (SPIS_MOSI_AUX_CTRL_DP0_REG)

#endif /* SPIS_DataWidth > 8u */

#define SPIS_COUNTER_PERIOD            (SPIS_COUNTER_PERIOD_REG)
#define SPIS_COUNTER_CONTROL           (SPIS_COUNTER_CONTROL_REG)
#define SPIS_ONE                       (SPIS_ONE_REG)
#define SPIS_STATUS                    (SPIS_TX_STATUS_REG)
#define SPIS_STATUS_MASK               (SPIS_TX_STATUS_MASK_REG)
#define SPIS_STATUS_ACTL               (SPIS_TX_STATUS_ACTL_REG)


/***************************************
*       Register Constants
***************************************/

/* Status Register Definitions */
#define SPIS_STS_SPI_DONE_SHIFT             (0x00u)
#define SPIS_STS_TX_FIFO_NOT_FULL_SHIFT     (0x01u)
#define SPIS_STS_TX_FIFO_EMPTY_SHIFT        (0x02u)
#define SPIS_STS_RX_FIFO_NOT_EMPTY_SHIFT    (0x03u)
#define SPIS_STS_RX_FIFO_EMPTY_SHIFT        (0x04u)
#define SPIS_STS_RX_FIFO_OVERRUN_SHIFT      (0x05u)
#define SPIS_STS_RX_FIFO_FULL_SHIFT         (0x06u)
#define SPIS_STS_BYTE_COMPLETE_SHIFT        (0x06u)

#define SPIS_STS_SPI_DONE                   (0x01u << SPIS_STS_SPI_DONE_SHIFT)
#define SPIS_STS_TX_FIFO_EMPTY              (0x01u << SPIS_STS_TX_FIFO_EMPTY_SHIFT)
#define SPIS_STS_TX_FIFO_NOT_FULL           (0x01u << SPIS_STS_TX_FIFO_NOT_FULL_SHIFT)
#define SPIS_STS_RX_FIFO_EMPTY              (0x01u << SPIS_STS_RX_FIFO_EMPTY_SHIFT)
#define SPIS_STS_RX_FIFO_NOT_EMPTY          (0x01u << SPIS_STS_RX_FIFO_NOT_EMPTY_SHIFT)
#define SPIS_STS_RX_FIFO_OVERRUN            (0x01u << SPIS_STS_RX_FIFO_OVERRUN_SHIFT)
#define SPIS_STS_RX_FIFO_FULL               (0x01u << SPIS_STS_RX_FIFO_FULL_SHIFT)
#define SPIS_STS_BYTE_COMPLETE              (0x01u << SPIS_STS_BYTE_COMPLETE_SHIFT)

#define SPIS_STS_CLR_ON_RD_BYTES_MASK       (0x61u)

/* StatusI Register Interrupt Enable Control Bits */
/* As defined by the Register map for the AUX Control Register */
#define SPIS_INT_ENABLE                     (0x10u)
#define SPIS_FIFO_CLR                       (0x03u)

/* Bit Counter (7-bit) Control Register Bit Definitions */
/* As defined by the Register map for the AUX Control Register */
#define SPIS_CNTR_ENABLE                    (0x20u)

/* Bi-Directional mode control bit */
#define SPIS_CTRL_TX_SIGNAL_EN              (0x01u)

/* Datapath Auxillary Control Register definitions */
#define SPIS_AUX_CTRL_FIFO0_CLR             (0x00u)
#define SPIS_AUX_CTRL_FIFO1_CLR             (0x00u)
#define SPIS_AUX_CTRL_FIFO0_LVL             (0x00u)
#define SPIS_AUX_CTRL_FIFO1_LVL             (0x00u)
#define SPIS_STATUS_ACTL_INT_EN_MASK        (0x10u)

/* Obosolete Status Register Definitions *DO NOT USE IN NEW DESIGNS* */
#define SPIS_STS_TX_BUF_NOT_FULL_SHIFT      (0x01u)
#define SPIS_STS_TX_BUF_FULL_SHIFT          (0x02u)
#define SPIS_STS_RX_BUF_NOT_EMPTY_SHIFT     (0x03u)
#define SPIS_STS_RX_BUF_EMPTY_SHIFT         (0x04u)
#define SPIS_STS_RX_BUF_OVERRUN_SHIFT       (0x05u)

#define SPIS_STS_TX_BUF_NOT_FULL            (0x01u << SPIS_STS_TX_BUF_NOT_FULL_SHIFT)
#define SPIS_STS_TX_BUF_FULL                (0x01u << SPIS_STS_TX_BUF_FULL_SHIFT)
#define SPIS_STS_RX_BUF_NOT_EMPTY           (0x01u << SPIS_STS_RX_BUF_NOT_EMPTY_SHIFT)
#define SPIS_STS_RX_BUF_EMPTY               (0x01u << SPIS_STS_RX_BUF_EMPTY_SHIFT)
#define SPIS_STS_RX_BUF_OVERRUN             (0x01u << SPIS_STS_RX_BUF_OVERRUN_SHIFT)

#endif  /* CY_SPIS_SPIS_H */


/* [] END OF FILE */
