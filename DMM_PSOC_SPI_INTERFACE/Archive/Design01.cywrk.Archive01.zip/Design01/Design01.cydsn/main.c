/* ========================================
 *
 * Copyright QMAX TEST EQUIPMENTS, 2014
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 * AUTHOR : RAVIVARMAN.R
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF QMAX TEST EQUIPMENTS.
 * CHANGED : 14TH FEB - D-FLIP_FLOP & BUFFERS
 * ========================================
*/
#include <device.h>

void main()
{
	uint8 m_u8MOSI=0,m_u8WRData=0;
	uint8 m_u8RLStatus[7];
	uint8 m_u8MISO=0;
	uint8 m_u8MOSI2=0;
	uint8 readStatus=0;
	SPIS_Start();
	
	/* Initializations */
	/* Clear All Relays */
	CyPins_ClearPin(RL1_CTR_P0_2);
	CyPins_ClearPin(RL2_CTR_P0_1);
	CyPins_ClearPin(RL3_CTR_P0_0);
	CyPins_ClearPin(RL4_CTR_P4_1);
	CyPins_ClearPin(RL5_CTR_P4_0);
	CyPins_ClearPin(RL6_CTR_P12_3);
	CyPins_ClearPin(RL7_CTR_P12_2);
			
	/* Set AC & DC Voltage as Default */
	CyPins_SetPin(RL2_CTR_P0_1);
	
    CyGlobalIntEnable;
	SPIS_ClearRxBuffer();
    for(;;)
    {
	if(CyPins_ReadPin(ISO_DI0_P15_3)!=0)
	{	
	
	for(m_u8WRData=0;m_u8WRData<10;m_u8WRData++){
		SPIS_WriteTxData(m_u8WRData);
		while(!(SPIS_ReadTxStatus() & SPIS_STS_TX_FIFO_EMPTY));
	}
//	while(!(SPIS_ReadRxStatus() & SPIS_STS_RX_FIFO_EMPTY)){
//		m_u8MOSI=SPIS_ReadRxData();       /* Read SPI Data */ 
//		SPIS_ClearRxBuffer();
//	}
//
//			if(m_u8MOSI == 0x80)		/* Read Buffer */
//			{
//				if(CyPins_ReadPin(RL1_CTR_P0_2)!=0)
//					m_u8RLStatus[0]=0x1;
//				else
//					m_u8RLStatus[0]=0;
//				CyDelayUs(10);
//				if(CyPins_ReadPin(RL2_CTR_P0_1)!=0)
//					m_u8RLStatus[1]=0x2;
//				else
//					m_u8RLStatus[1]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL3_CTR_P0_0)!=0)
//					m_u8RLStatus[2]=0x4;
//				else
//					m_u8RLStatus[2]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL4_CTR_P4_1)!=0)
//					m_u8RLStatus[3]=0x8;
//				else
//					m_u8RLStatus[3]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL5_CTR_P4_0)!=0)
//					m_u8RLStatus[4]=0x16;
//				else
//					m_u8RLStatus[4]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL6_CTR_P12_3)!=0)
//					m_u8RLStatus[5]=0x32;
//				else
//					m_u8RLStatus[5]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL7_CTR_P12_2)!=0)
//					m_u8RLStatus[6]=0x64;
//				else
//					m_u8RLStatus[6]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				
//				m_u8MISO = m_u8RLStatus[0] | m_u8RLStatus[1] | m_u8RLStatus[2] | m_u8RLStatus[3] | m_u8RLStatus[4] | m_u8RLStatus[5] | m_u8RLStatus[6] ;
//					
//				SPIS_ClearTxBuffer();
//				SPIS_WriteTxData(m_u8MISO);
//				while(!(SPIS_ReadTxStatus() & SPIS_STS_TX_FIFO_EMPTY));
//			}
//			else							/* Write Mode */
//			{
//				m_u8WRData = m_u8MOSI & 0x07;
//				switch(m_u8WRData)
//				{
//					case 0x00:									//ACV & DCV Mode
//						CyPins_ClearPin(RL1_CTR_P0_2);
//						CyPins_SetPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//
//					case 0x01:									//ACmV & DCmV Mode
//						CyPins_SetPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x02:									//ACI & DCI Mode	-	Amps
//						CyPins_ClearPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_SetPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x03:									//ACI & DCI Mode	-	mA
//						CyPins_ClearPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_SetPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x04:									//ACI & DCI Mode	-	uA
//						CyPins_ClearPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_SetPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x05:									//Resistor,Continuity,Diode&Capacitor
//						CyPins_SetPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_ClearPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x06:									//Frequency
//						CyPins_SetPin(RL1_CTR_P0_2);
//						CyPins_ClearPin(RL2_CTR_P0_1);
//						CyPins_SetPin(RL3_CTR_P0_0);
//						CyPins_ClearPin(RL4_CTR_P4_1);
//						CyPins_ClearPin(RL5_CTR_P4_0);
//						CyPins_ClearPin(RL6_CTR_P12_3);
//						CyPins_ClearPin(RL7_CTR_P12_2);
//						CyDelay(10);// 10 milli seconds delay
//					break;
//					case 0x07:
//						break;
//				}
//				
//				if(CyPins_ReadPin(RL1_CTR_P0_2)!=0)
//					m_u8RLStatus[0]=0x1;
//				else
//					m_u8RLStatus[0]=0;
//				CyDelayUs(10);
//				if(CyPins_ReadPin(RL2_CTR_P0_1)!=0)
//					m_u8RLStatus[1]=0x2;
//				else
//					m_u8RLStatus[1]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL3_CTR_P0_0)!=0)
//					m_u8RLStatus[2]=0x4;
//				else
//					m_u8RLStatus[2]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL4_CTR_P4_1)!=0)
//					m_u8RLStatus[3]=0x8;
//				else
//					m_u8RLStatus[3]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL5_CTR_P4_0)!=0)
//					m_u8RLStatus[4]=0x16;
//				else
//					m_u8RLStatus[4]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL6_CTR_P12_3)!=0)
//					m_u8RLStatus[5]=0x32;
//				else
//					m_u8RLStatus[5]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				if(CyPins_ReadPin(RL7_CTR_P12_2)!=0)
//					m_u8RLStatus[6]=0x64;
//				else
//					m_u8RLStatus[6]=0;
//				CyDelayUs(10);// 10 micro seconds delay
//				
//				m_u8MISO = m_u8RLStatus[0] | m_u8RLStatus[1] | m_u8RLStatus[2] | m_u8RLStatus[3] | m_u8RLStatus[4] | m_u8RLStatus[5] | m_u8RLStatus[6] ;
//				
//				//SPIS_ClearTxBuffer();
//				SPIS_WriteTxData(m_u8MISO);
//				while(!(SPIS_ReadTxStatus() & SPIS_STS_TX_FIFO_EMPTY));
//			}
//		
	 	}
    }
}

/* [] END OF FILE */
